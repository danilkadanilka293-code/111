package com.example.minuteanomalies;

import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.RandomSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.entity.animal.Chicken;
import net.minecraft.world.entity.animal.Pig;
import net.minecraft.world.entity.animal.Rabbit;
import net.minecraft.world.entity.monster.Enderman;
import net.minecraft.world.entity.monster.Spider;
import net.minecraft.world.entity.monster.Zombie;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.saveddata.SavedData;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.ArrayList;
import java.util.List;

@Mod(MinuteAnomalies.MOD_ID)
public class MinuteAnomalies {
    public static final String MOD_ID = "minuteanomalies";
    private static final int TICKS_PER_MINUTE = 1200;

    public MinuteAnomalies() {}

    @Mod.EventBusSubscriber(modid = MOD_ID)
    public static class ServerEvents {
        @SubscribeEvent
        public static void onServerTick(TickEvent.ServerTickEvent event) {
            if (event.phase != TickEvent.Phase.END) return;
            MinecraftServer server = event.getServer();
            ServerLevel level = server.overworld();
            AnomalyData data = AnomalyData.get(level);

            data.ticks++;
            if (data.ticks >= TICKS_PER_MINUTE && data.eventIndex < 60) {
                data.ticks = 0;
                data.eventIndex++;
                data.setDirty();
                Anomalies.run(data.eventIndex, server, level);
            }
        }
    }

    public static class AnomalyData extends SavedData {
        int ticks = 0;
        int eventIndex = 0;

        static AnomalyData get(ServerLevel level) {
            return level.getDataStorage().computeIfAbsent(
                new SavedData.Factory<>(AnomalyData::new, AnomalyData::load, null),
                MOD_ID + "_progress"
            );
        }

        static AnomalyData load(CompoundTag tag) {
            AnomalyData d = new AnomalyData();
            d.ticks = tag.getInt("Ticks");
            d.eventIndex = tag.getInt("EventIndex");
            return d;
        }

        @Override
        public CompoundTag save(CompoundTag tag) {
            tag.putInt("Ticks", ticks);
            tag.putInt("EventIndex", eventIndex);
            return tag;
        }
    }

    static class Anomalies {
        static void run(int n, MinecraftServer server, ServerLevel level) {
            switch (n) {
                case 1 -> msg(server, "§7Что-то в этом мире стало немного не так.");
                case 2 -> particles(level, 40);
                case 3 -> rain(level);
                case 4 -> darkenSky(level);
                case 5 -> moss(level, 12);
                case 6 -> flowers(level, 8);
                case 7 -> whispers(server, "§8Ты точно один?");
                case 8 -> spawnChickens(level, 3);
                case 9 -> swapTorches(level);
                case 10 -> fogMessage(server, "§7Расстояние кажется немного меньше.");
                case 11 -> nightMoment(level);
                case 12 -> growVines(level, 10);
                case 13 -> spawnRabbits(level, 2);
                case 14 -> randomSounds(server);
                case 15 -> coarseDirt(level, 10);
                case 16 -> waterRipple(level);
                case 17 -> spawnPigs(level, 2);
                case 18 -> leafDrop(level);
                case 19 -> shortBlindness(server);
                case 20 -> renameWorld(server, "§5Мир смотрит.");
                case 21 -> cobwebs(level, 4);
                case 22 -> pumpkins(level, 3);
                case 23 -> reverseSigns(server);
                case 24 -> enderman(level);
                case 25 -> snowDust(level);
                case 26 -> grassPath(level);
                case 27 -> moonMessage(server);
                case 28 -> spider(level);
                case 29 -> moreParticles(level);
                case 30 -> smallHoles(level);
                case 31 -> rain(level);
                case 32 -> mushrooms(level);
                case 33 -> zombies(level);
                case 34 -> vines(level);
                case 35 -> lightning(level);
                case 36 -> strangeFlowers(level);
                case 37 -> rabbitJump(level);
                case 38 -> waterToIce(level);
                case 39 -> torchExtinguish(level);
                case 40 -> messageAll(server, "§8[Эхо] §7Мы уже были здесь.");
                case 41 -> moreMoss(level);
                case 42 -> spiders(level);
                case 43 -> leaves(level);
                case 44 -> darkness(server);
                case 45 -> dirtPatches(level);
                case 46 -> flowers(level, 16);
                case 47 -> rain(level);
                case 48 -> cobwebs(level, 8);
                case 49 -> enderman(level);
                case 50 -> strangeFlowers(level);
                case 51 -> zombies(level);
                case 52 -> treesFeelWrong(server);
                case 53 -> waterRipple(level);
                case 54 -> lightning(level);
                case 55 -> moreMoss(level);
                case 56 -> spiders(level);
                case 57 -> finalWhisper(server);
                case 58 -> finalLandscape(level);
                case 59 -> finalNight(level);
                case 60 -> finale(server, level);
            }
        }

        private static List<ServerPlayer> players(MinecraftServer server) {
            return server.getPlayerList().getPlayers();
        }

        private static void msg(MinecraftServer s, String text) {
            s.getPlayerList().broadcastSystemMessage(Component.literal(text), false);
        }

        private static void messageAll(MinecraftServer s, String text) {
            msg(s, text);
        }

        private static ServerPlayer randomPlayer(MinecraftServer s) {
            List<ServerPlayer> p = players(s);
            return p.isEmpty() ? null : p.get(s.overworld().random.nextInt(p.size()));
        }

        private static BlockPos around(ServerPlayer p, RandomSource r, int radius, int yOffset) {
            return p.blockPosition().offset(r.nextInt(radius * 2 + 1) - radius, yOffset, r.nextInt(radius * 2 + 1) - radius);
        }

        private static void particles(ServerLevel l, int amount) {
            for (ServerPlayer p : l.players()) {
                l.sendParticles(net.minecraft.core.particles.ParticleTypes.ASH, p.getX(), p.getY() + 1, p.getZ(), amount, 3, 1, 3, 0.01);
            }
        }

        private static void rain(ServerLevel l) {
            l.setWeatherParameters(0, 20 * 35, true, false);
        }

        private static void darkenSky(ServerLevel l) {
            l.setWeatherParameters(0, 20 * 25, true, true);
        }

        private static void moss(ServerLevel l, int count) {
            for (ServerPlayer p : l.players()) {
                RandomSource r = l.random;
                for (int i = 0; i < count; i++) {
                    BlockPos pos = around(p, r, 10, -1);
                    if (l.getBlockState(pos).is(Blocks.GRASS_BLOCK) && l.getBlockState(pos.above()).isAir())
                        l.setBlock(pos, Blocks.MOSS_BLOCK.defaultBlockState(), 3);
                }
            }
        }

        private static void moreMoss(ServerLevel l) { moss(l, 25); }

        private static void flowers(ServerLevel l, int count) {
            for (ServerPlayer p : l.players()) {
                for (int i = 0; i < count; i++) {
                    BlockPos pos = around(p, l.random, 8, 0);
                    if (l.getBlockState(pos).is(Blocks.GRASS_BLOCK) && l.getBlockState(pos.above()).isAir())
                        l.setBlock(pos.above(), Blocks.DANDELION.defaultBlockState(), 3);
                }
            }
        }

        private static void strangeFlowers(ServerLevel l) {
            for (ServerPlayer p : l.players()) {
                for (int i = 0; i < 10; i++) {
                    BlockPos pos = around(p, l.random, 12, 0).above();
                    if (l.getBlockState(pos).isAir())
                        l.setBlock(pos, Blocks.BLUE_ORCHID.defaultBlockState(), 3);
                }
            }
        }

        private static void whispers(MinecraftServer s, String text) {
            ServerPlayer p = randomPlayer(s);
            if (p != null) p.sendSystemMessage(Component.literal(text));
        }

        private static void spawnChickens(ServerLevel l, int count) {
            spawnAnimals(l, EntityType.CHICKEN, count);
        }

        private static void spawnRabbits(ServerLevel l, int count) {
            spawnAnimals(l, EntityType.RABBIT, count);
        }

        private static void spawnPigs(ServerLevel l, int count) {
            spawnAnimals(l, EntityType.PIG, count);
        }

        private static <T extends net.minecraft.world.entity.Mob> void spawnAnimals(ServerLevel l, EntityType<T> type, int count) {
            for (ServerPlayer p : l.players()) {
                for (int i = 0; i < count; i++) {
                    T mob = type.create(l);
                    if (mob != null) {
                        BlockPos pos = around(p, l.random, 8, 0);
                        mob.moveTo(pos.getX() + .5, pos.getY() + 1, pos.getZ() + .5, l.random.nextFloat() * 360, 0);
                        l.addFreshEntity(mob);
                    }
                }
            }
        }

        private static void swapTorches(ServerLevel l) {
            for (ServerPlayer p : l.players()) {
                BlockPos pos = p.blockPosition().below();
                if (l.getBlockState(pos).is(Blocks.TORCH)) l.setBlock(pos, Blocks.SOUL_TORCH.defaultBlockState(), 3);
            }
        }

        private static void fogMessage(MinecraftServer s, String text) { msg(s, text); }

        private static void nightMoment(ServerLevel l) {
            l.setDayTime(l.getDayTime() + 600);
        }

        private static void growVines(ServerLevel l, int count) {
            for (ServerPlayer p : l.players()) {
                for (int i = 0; i < count; i++) {
                    BlockPos pos = around(p, l.random, 8, 1);
                    if (l.getBlockState(pos).isAir() && l.getBlockState(pos.below()).isSolid())
                        l.setBlock(pos, Blocks.VINE.defaultBlockState(), 3);
                }
            }
        }

        private static void randomSounds(MinecraftServer s) {
            ServerPlayer p = randomPlayer(s);
            if (p != null)
                p.playNotifySound(net.minecraft.sounds.SoundEvents.AMBIENT_CAVE.get(), net.minecraft.sounds.SoundSource.AMBIENT, 1.0f, 0.7f);
        }

        private static void coarseDirt(ServerLevel l, int count) {
            for (ServerPlayer p : l.players()) {
                for (int i = 0; i < count; i++) {
                    BlockPos pos = around(p, l.random, 10, -1);
                    if (l.getBlockState(pos).is(Blocks.DIRT) && l.getBlockState(pos.above()).isAir())
                        l.setBlock(pos, Blocks.COARSE_DIRT.defaultBlockState(), 3);
                }
            }
        }

        private static void waterRipple(ServerLevel l) {
            for (ServerPlayer p : l.players())
                l.sendParticles(net.minecraft.core.particles.ParticleTypes.SPLASH, p.getX(), p.getY(), p.getZ(), 25, 2, .5, 2, .1);
        }

        private static void leafDrop(ServerLevel l) {
            for (ServerPlayer p : l.players())
                l.sendParticles(net.minecraft.core.particles.ParticleTypes.FALLING_SPORE_BLOSSOM, p.getX(), p.getY()+2, p.getZ(), 20, 3, 2, 3, .02);
        }

        private static void shortBlindness(MinecraftServer s) {
            for (ServerPlayer p : players(s))
                p.addEffect(new MobEffectInstance(MobEffects.DARKNESS, 60, 0, false, false));
        }

        private static void renameWorld(MinecraftServer s, String text) { msg(s, text); }

        private static void cobwebs(ServerLevel l, int count) {
            for (ServerPlayer p : l.players()) {
                for (int i = 0; i < count; i++) {
                    BlockPos pos = around(p, l.random, 10, 1);
                    if (l.getBlockState(pos).isAir())
                        l.setBlock(pos, Blocks.COBWEB.defaultBlockState(), 3);
                }
            }
        }

        private static void pumpkins(ServerLevel l, int count) {
            for (ServerPlayer p : l.players()) {
                for (int i = 0; i < count; i++) {
                    BlockPos pos = around(p, l.random, 10, 0);
                    if (l.getBlockState(pos).isAir() && l.getBlockState(pos.below()).isSolid())
                        l.setBlock(pos, Blocks.CARVED_PUMPKIN.defaultBlockState(), 3);
                }
            }
        }

        private static void reverseSigns(MinecraftServer s) { msg(s, "§8Некоторые надписи больше не кажутся правильными."); }

        private static void enderman(ServerLevel l) {
            ServerPlayer p = l.players().isEmpty() ? null : l.players().get(l.random.nextInt(l.players().size()));
            if (p != null) {
                Enderman e = EntityType.ENDERMAN.create(l);
                if (e != null) {
                    BlockPos pos = p.blockPosition().offset(12, 0, 12);
                    e.moveTo(pos.getX()+.5, pos.getY(), pos.getZ()+.5, 0, 0);
                    l.addFreshEntity(e);
                }
            }
        }

        private static void snowDust(ServerLevel l) {
            for (ServerPlayer p : l.players())
                l.sendParticles(net.minecraft.core.particles.ParticleTypes.SNOWFLAKE, p.getX(), p.getY()+2, p.getZ(), 30, 3, 2, 3, .02);
        }

        private static void grassPath(ServerLevel l) {
            for (ServerPlayer p : l.players()) {
                BlockPos pos = p.blockPosition().below();
                if (l.getBlockState(pos).is(Blocks.GRASS_BLOCK))
                    l.setBlock(pos, Blocks.DIRT_PATH.defaultBlockState(), 3);
            }
        }

        private static void moonMessage(MinecraftServer s) { msg(s, "§7Луна сегодня выглядит слишком близкой."); }

        private static void spider(ServerLevel l) { spawnHostile(l, EntityType.SPIDER); }

        private static void spiders(ServerLevel l) {
            spawnHostile(l, EntityType.SPIDER);
            spawnHostile(l, EntityType.SPIDER);
        }

        private static void spawnHostile(ServerLevel l, EntityType<? extends net.minecraft.world.entity.Mob> type) {
            if (l.players().isEmpty()) return;
            ServerPlayer p = l.players().get(l.random.nextInt(l.players().size()));
            var mob = type.create(l);
            if (mob != null) {
                BlockPos pos = p.blockPosition().offset(10, 0, 10);
                mob.moveTo(pos.getX()+.5, pos.getY(), pos.getZ()+.5, 0, 0);
                l.addFreshEntity(mob);
            }
        }

        private static void moreParticles(ServerLevel l) {
            particles(l, 100);
        }

        private static void smallHoles(ServerLevel l) {
            for (ServerPlayer p : l.players()) {
                BlockPos pos = p.blockPosition().below();
                if (l.getBlockState(pos).is(Blocks.GRASS_BLOCK))
                    l.setBlock(pos, Blocks.DIRT.defaultBlockState(), 3);
            }
        }

        private static void mushrooms(ServerLevel l) {
            for (ServerPlayer p : l.players()) {
                BlockPos pos = around(p, l.random, 10, 0).above();
                if (l.getBlockState(pos).isAir())
                    l.setBlock(pos, Blocks.RED_MUSHROOM.defaultBlockState(), 3);
            }
        }

        private static void zombies(ServerLevel l) { spawnHostile(l, EntityType.ZOMBIE); }

        private static void vines(ServerLevel l) { growVines(l, 20); }

        private static void lightning(ServerLevel l) {
            if (l.players().isEmpty()) return;
            ServerPlayer p = l.players().get(l.random.nextInt(l.players().size()));
            LightningBolt bolt = EntityType.LIGHTNING_BOLT.create(l);
            if (bolt != null) {
                BlockPos pos = p.blockPosition().offset(8, 0, 8);
                bolt.moveTo(pos.getX(), pos.getY(), pos.getZ());
                bolt.setVisualOnly(true);
                l.addFreshEntity(bolt);
            }
        }

        private static void rabbitJump(ServerLevel l) {
            for (ServerPlayer p : l.players()) {
                p.sendSystemMessage(Component.literal("§7Кролики сегодня почему-то прыгают выше."));
            }
        }

        private static void waterToIce(ServerLevel l) {
            for (ServerPlayer p : l.players()) {
                BlockPos pos = p.blockPosition().below();
                if (l.getBlockState(pos).is(Blocks.WATER))
                    l.setBlock(pos, Blocks.ICE.defaultBlockState(), 3);
            }
        }

        private static void torchExtinguish(ServerLevel l) {
            for (ServerPlayer p : l.players()) {
                BlockPos pos = p.blockPosition().below();
                if (l.getBlockState(pos).is(Blocks.TORCH))
                    l.setBlock(pos, Blocks.AIR.defaultBlockState(), 3);
            }
        }

        private static void darkness(MinecraftServer s) {
            for (ServerPlayer p : players(s))
                p.addEffect(new MobEffectInstance(MobEffects.DARKNESS, 100, 0, false, false));
        }

        private static void dirtPatches(ServerLevel l) { coarseDirt(l, 25); }

        private static void leaves(ServerLevel l) {
            for (ServerPlayer p : l.players())
                l.sendParticles(net.minecraft.core.particles.ParticleTypes.CHERRY_LEAVES, p.getX(), p.getY()+2, p.getZ(), 60, 4, 2, 4, .02);
        }

        private static void treesFeelWrong(MinecraftServer s) {
            msg(s, "§8Ты начинаешь замечать, что деревья стоят не совсем там, где раньше.");
        }

        private static void finalWhisper(MinecraftServer s) {
            msg(s, "§5[?] §7Осталась одна минута.");
        }

        private static void finalLandscape(ServerLevel l) {
            moss(l, 50);
            flowers(l, 25);
            cobwebs(l, 12);
            growVines(l, 35);
        }

        private static void finalNight(ServerLevel l) {
            l.setDayTime(l.getDayTime() + 12000);
            l.setWeatherParameters(0, 20 * 60, true, true);
        }

        private static void finale(MinecraftServer s, ServerLevel l) {
            msg(s, "§5§lМИР ИЗМЕНИЛСЯ.");
            particles(l, 250);
            finalLandscape(l);
            for (ServerPlayer p : players(s)) {
                p.addEffect(new MobEffectInstance(MobEffects.DARKNESS, 120, 0, false, false));
                p.sendSystemMessage(Component.literal("§8Шестьдесят минут. Теперь это место помнит тебя."));
            }
        }
    }
}
